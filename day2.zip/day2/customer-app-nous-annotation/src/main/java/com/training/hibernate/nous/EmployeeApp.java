package com.training.hibernate.nous;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.hibernate.nous.model.Customer;
import com.training.hibernate.nous.model.Employee;

public class EmployeeApp 
{
    public static void main( String[] args )
    {
    	//Hands on : 11:10 PM 15 minutes 
        // You have to save employee information in DB using hibernate annotations
    	Employee employee = new Employee(18167, "Tarun", 178000);
    	
    	//this will create the connection by reading information from hibernate.cfg.xml
    	Configuration configuration = new Configuration().configure();	
    	SessionFactory sessionFactory = configuration.buildSessionFactory();
    	Session session = sessionFactory.openSession();
    	
    	Transaction transaction = session.beginTransaction();
    	session.save(employee);
    	transaction.commit();
    	
    	System.out.println("Employee record saved successfully - Annotation way");
    	
    	session.close();
    	sessionFactory.close();
    }
}
