package com.training.hibernate.nous.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee100")
public class Employee {
	
		@Id
		@Column(name = "emp_id")
		private int employeeId;
		
		@Column(name = "emp_name")
		private String employeeName;
		
		@Column(name = "salary")
		private int salary;
		
		public Employee() {
			// TODO Auto-generated constructor stub
		}

		public Employee(int employeeId, String employeeName, int salary) {
			super();
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.salary = salary;
		}

		public int getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}

		public String getEmployeeName() {
			return employeeName;
		}

		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}

		public int getSalary() {
			return salary;
		}

		public void setSalary(int salary) {
			this.salary = salary;
		}
		
}
