package com.training.hibernate.nous.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer100")
public class Customer {
	
		@Id
		@Column(name = "cust_id")
		private int customerId;
		
		@Column(name = "cust_name")
		private String customerName;
		
		@Column(name = "mobile")
		private String mobileNumber;
		
		@Column(name = "balance")
		private int billAmount;
		
		public Customer() {
			
		}

		public Customer(int customerId, String customerName, String mobileNumber, int billAmount) {
			super();
			this.customerId = customerId;
			this.customerName = customerName;
			this.mobileNumber = mobileNumber;
			this.billAmount = billAmount;
		}

		public int getCustomerId() {
			return customerId;
		}

		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}

		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public String getMobileNumber() {
			return mobileNumber;
		}

		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}

		public int getBillAmount() {
			return billAmount;
		}

		public void setBillAmount(int billAmount) {
			this.billAmount = billAmount;
		}

		@Override
		public String toString() {
			return "\nCustomer [customerId=" + customerId + ", customerName=" + customerName + ", mobileNumber="
					+ mobileNumber + ", billAmount=" + billAmount + "]";
		}
		
}
