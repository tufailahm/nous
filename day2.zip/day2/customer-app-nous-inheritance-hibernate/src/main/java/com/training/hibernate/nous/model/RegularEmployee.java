package com.training.hibernate.nous.model;

public class RegularEmployee extends Employee{

	private int bonus;
	private int salary;
	
	public RegularEmployee() {
		// TODO Auto-generated constructor stub
	}

	public RegularEmployee(int bonus, int salary) {
		super();
		this.bonus = bonus;
		this.salary = salary;
	}

	public int getBonus() {
		return bonus;
	}

	public void setBonus(int bonus) {
		this.bonus = bonus;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "RegularEmployee [bonus=" + bonus + ", salary=" + salary + "]";
	}
	
	
}
