package com.training.hibernate.nous;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.hibernate.nous.model.ContractEmployee;
import com.training.hibernate.nous.model.Customer;
import com.training.hibernate.nous.model.Employee;
import com.training.hibernate.nous.model.RegularEmployee;
//20 minutes for hands on
//12:26 PM 
public class EmployeeApp 
{
    public static void main( String[] args )
    {
        
    	Employee employee = new Employee(18167, "Tarun");
    	
    	RegularEmployee regularEmployee = new RegularEmployee();
    	regularEmployee.setEmployeeId(18161);
    	regularEmployee.setEmployeeName("Chandana");
    	regularEmployee.setSalary(78000);
    	regularEmployee.setBonus(95000);
    	
    	ContractEmployee contractEmployee = new ContractEmployee();
    	contractEmployee.setEmployeeId(272653);
    	contractEmployee.setEmployeeName("Tufail");
    	contractEmployee.setPayPerHour(6000);
    	contractEmployee.setContractDuration(8);
    	
    	
    	//this will create the connection by reading information from hibernate.cfg.xml
    	Configuration configuration = new Configuration().configure();	
    	SessionFactory sessionFactory = configuration.buildSessionFactory();
    	Session session = sessionFactory.openSession();
    	
    	Transaction transaction = session.beginTransaction();
    	session.save(employee);
    	session.save(regularEmployee);
    	session.save(contractEmployee);
    	transaction.commit();
    	
    	System.out.println("All Employee record saved successfully - Inheritance Table Per sub class");
    	
    	session.close();
    	sessionFactory.close();
    }
}
