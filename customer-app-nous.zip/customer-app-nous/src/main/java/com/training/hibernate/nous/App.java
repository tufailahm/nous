package com.training.hibernate.nous;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.hibernate.nous.model.Customer;

public class App {
	Configuration configuration;
	SessionFactory sessionFactory;
	int customerId, billAmount;
	String customerName, mobileNumber;
	static Scanner scanner = new Scanner(System.in);

	public App() {
		configuration = new Configuration().configure();
		sessionFactory = configuration.buildSessionFactory();
	}

	public static void main(String[] args) {
		App a = new App();
		while (true) {
			System.out.println("M E N U ");
			System.out.println("1. Add customer");
			System.out.println("2. Update customer");
			System.out.println("3. Delete customer");
			System.out.println("4. View All customers");
			System.out.println("5. Find customer By Id");
			
			System.out.println("5. Find customer By Name");
			System.out.println("9. E X I T");
			System.out.println("Enter your choice : ");
			int choice = scanner.nextInt();
			if (choice == 1) {
				a.saveCustomer();
			}
			if (choice == 2) {
				a.updateCustomer();
			}
			if (choice == 3) {
				a.deleteCustomer();
			}
			if (choice == 4) {
				a.getCustomers();
			}
			if (choice == 5) {
				a.getCustomerById();
			}
			if (choice == 9) {
				System.out.println("Thanks for using my program");
				System.exit(0);
			}
		}
	}

	// for saving customer
	public void saveCustomer() {
		System.out.println("WELCOME in save customer section .... ");
		System.out.println("Enter customer id  :");
		customerId = scanner.nextInt();
		System.out.println("Enter customer name  :");
		customerName = scanner.next();
		System.out.println("Enter customer mobile number :");
		mobileNumber = scanner.next();
		System.out.println("Enter customer bill amount  :");
		billAmount = scanner.nextInt();

		Customer customer = new Customer(customerId, customerName, mobileNumber, billAmount);

		Session session = sessionFactory.openSession();

		Transaction transaction = session.beginTransaction();
		session.save(customer);
		transaction.commit();

		System.out.println(customerName + " , your record saved successfully");

		session.close();
	}

	// for deleting customer
	// 10 minutes 4:35 PM
	public void deleteCustomer() {
		System.out.println("WELCOME in delete customer section .... ");
		System.out.println("Enter customer id to delete :");
		customerId = scanner.nextInt();

		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Customer customer = new Customer();
		customer.setCustomerId(customerId);

		session.delete(customer);
		transaction.commit();

		System.out.println(customerId + " , your record deleted successfully");

		session.close();
	}

	// for update customer
	public void updateCustomer() {
		System.out.println("WELCOME in update customer section .... ");
		System.out.println("Enter customer id to update :");
		customerId = scanner.nextInt();
		System.out.println("Enter new customer name  :");
		customerName = scanner.next();
		System.out.println("Enter new customer mobile number :");
		mobileNumber = scanner.next();
		System.out.println("Enter new customer bill amount  :");
		billAmount = scanner.nextInt();

		Customer customer = new Customer(customerId, customerName, mobileNumber, billAmount);

		Session session = sessionFactory.openSession();

		Transaction transaction = session.beginTransaction();
		session.update(customer);
		transaction.commit();

		System.out.println(customerName + " , your record update successfully");

		session.close();
	}

	// for retrieving all the customers
	public void getCustomers() {
		System.out.println("All the customers data .... ");

		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from com.training.hibernate.nous.model.Customer");
		List<Customer> customers = query.list();
		System.out.println(customers);

		session.close();
	}
	
	// for retrieving all the customers
		public void getCustomerById() {
			System.out.println("WELCOME in get customer by idsection .... ");
			System.out.println("Enter customer id to retrieve :");
			customerId = scanner.nextInt();
			Session session = sessionFactory.openSession();
			Customer customer = session.get(Customer.class,customerId);
			
			System.out.println(customer);

			session.close();
		}
}