package com.training.hibernate.nous.model;

public class Employee {
		private int employeeId;
		private String employeeName;
		private int salary;
		
		public Employee() {
			// TODO Auto-generated constructor stub
		}

		public Employee(int employeeId, String employeeName, int salary) {
			super();
			this.employeeId = employeeId;
			this.employeeName = employeeName;
			this.salary = salary;
		}

		public int getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}

		public String getEmployeeName() {
			return employeeName;
		}

		public void setEmployeeName(String employeeName) {
			this.employeeName = employeeName;
		}

		public int getSalary() {
			return salary;
		}

		public void setSalary(int salary) {
			this.salary = salary;
		}
		
}
