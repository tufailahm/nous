package com.training.pms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.pms.model.Product;
import com.training.pms.service.ProductService;

@RestController
@RequestMapping("product") // localhost:9090/product
@CrossOrigin(origins = "http://localhost:4200")
public class ProductController {

	@Autowired
	ProductService productService;

	@PostMapping // localhost:9090/product -POST
	public ResponseEntity<String> saveProduct(@RequestBody Product product) {
		System.out.println(product);
		ResponseEntity<String> responseEntity = null;
		String message = null;
		if (productService.isProductExists(product.getProductId())) {
			message = "Product with product id :" + product.getProductId() + " already exists";
			responseEntity = new ResponseEntity<String>(message, HttpStatus.CONFLICT); // 409
		} else {
			message = productService.saveProduct(product);
			if (message.equals("Product saved successfully")) {
				responseEntity = new ResponseEntity<String>(message, HttpStatus.CREATED); // 201
			} else {
				responseEntity = new ResponseEntity<String>(message, HttpStatus.NOT_ACCEPTABLE); // 406
			}
		}
		return responseEntity;
	}

	@PutMapping
	public ResponseEntity<String> updateProduct(@RequestBody Product product) {

		ResponseEntity<String> responseEntity = null;

		String successMessage = null;
		if (productService.isProductExists(product.getProductId())) {
			// msg1="Product with Id "+ product.getProductId() +"exists...";
			successMessage = productService.updateProduct(product);
			if (successMessage.equals("Congrats..!! Product updated successfully..!!")) {
				responseEntity = new ResponseEntity<String>(successMessage, HttpStatus.OK); // 200
			} else {
				responseEntity = new ResponseEntity<String>(successMessage, HttpStatus.NOT_ACCEPTABLE); // 406

			}
		} else {
			responseEntity = new ResponseEntity<String>(successMessage, HttpStatus.NO_CONTENT); // 204
			successMessage = "Product with Id " + product.getProductId() + " does not exists...";
		}
		return responseEntity;
	}

	@GetMapping // localhost:9090/product // localhost:9090/product?productName=Aroma
	public ResponseEntity<List<Product>> getProducts(@RequestParam(required = false) String productName) {

		ResponseEntity<List<Product>> responseEntity = null;
		List<Product> products = new ArrayList<Product>();
		if (productName == null) {
			products = productService.getProducts();
		} else {
			products = productService.getProductByName(productName);
		}
		if (products.size() == 0)
			responseEntity = new ResponseEntity<List<Product>>(products, HttpStatus.NO_CONTENT);
		else
			responseEntity = new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		return responseEntity;
	}
	
	
	@GetMapping("/{productId}") // localhost:9090/product/8171 -GET	localhost:9090/product/990?quantityOnHand=5000
	public ResponseEntity<Product> getProductById(@PathVariable("productId") int productId, 
			@RequestParam(required = false)Integer quantityOnHand) {
		ResponseEntity<Product> responseEntity = null;
		Product product = new Product();
		if (productService.isProductExists(productId)) {
			if(quantityOnHand == null)
			{
				product = productService.getProduct(productId);
			}
			else
			{
				product = productService.getProductByQuantityAndProductId(quantityOnHand, productId);
			}
			responseEntity = new ResponseEntity<Product>(product, HttpStatus.OK); // 200
		} else {
			responseEntity = new ResponseEntity<Product>(product, HttpStatus.NO_CONTENT); // 204
		}
		return responseEntity;
	}
	
	
	
	
	
	
	
	
	

	@DeleteMapping("/{productId}")
	public ResponseEntity<String> deleteProduct(@PathVariable("productId") int productId) {
		// code to delete will come
		ResponseEntity<String> responseEntity = null;
		String successMessage = null;
		if (productService.isProductExists(productId)) {
			successMessage = productService.deleteProduct(productId);
			responseEntity = new ResponseEntity<String>(successMessage, HttpStatus.OK); // 200
		} else {
			responseEntity = new ResponseEntity<String>(successMessage, HttpStatus.NO_CONTENT); // 204
			successMessage = "Product with Id " + productId + " does not exists...";
		}
		return responseEntity;
	}

	

	@GetMapping("/getProductByName/{productName}") // localhost:9090/product/getProductByName/lakme -GET
	public ResponseEntity<List<Product>> getProduct(@PathVariable("productName") String productName) {
		ResponseEntity<List<Product>> responseEntity = null;
		List<Product> products = productService.getProductByName(productName);
		if (products.size() == 0) {
			responseEntity = new ResponseEntity<List<Product>>(products, HttpStatus.NO_CONTENT);
		} else {
			responseEntity = new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		return responseEntity;
	}

	@GetMapping("/getProductByPrice/{price}") // localhost:9090/product/getProductByPrice/5000 -GET
	public ResponseEntity<List<Product>> getProductByGreaterThanPrice(@PathVariable("price") int price) {
		ResponseEntity<List<Product>> responseEntity = null;
		List<Product> products = productService.getProductByPrice(price);
		if (products.size() == 0) {
			responseEntity = new ResponseEntity<List<Product>>(products, HttpStatus.NO_CONTENT);
		} else {
			responseEntity = new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		return responseEntity;
	}

	// Hands on //localhost:9090/product/filterProductByPrice/5000/to/9000
	// getting all the products between 5000 and 9000

	// Hands on //localhost:9090/product/filterProductByPrice/10000/to/12000
	// getting all the products between 10000 and 12000
	// ??

	@GetMapping("/filterProductByPrice/{min_price}/to/{max_price}")
	public ResponseEntity<List<Product>> getProductsInPriceRange(@PathVariable("min_price") int min,
			@PathVariable("max_price") int max) {
		ResponseEntity<List<Product>> responseEntity = null;
		List<Product> products = productService.getProductByPrice(min, max);
		if (products.size() == 0) {
			responseEntity = new ResponseEntity<List<Product>>(products, HttpStatus.NO_CONTENT);
		} else {
			responseEntity = new ResponseEntity<List<Product>>(products, HttpStatus.OK);
		}
		return responseEntity;
	}
}
