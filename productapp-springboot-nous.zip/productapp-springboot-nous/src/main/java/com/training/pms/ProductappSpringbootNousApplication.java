package com.training.pms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductappSpringbootNousApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductappSpringbootNousApplication.class, args);
	}

}
