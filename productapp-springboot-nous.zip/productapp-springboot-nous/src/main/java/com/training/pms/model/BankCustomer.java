package com.training.pms.model;

public class BankCustomer {
		private int customerId;
		private String customerName;
		private String password;
		private int accountBalance;
		
		public BankCustomer() {
			// TODO Auto-generated constructor stub
		}

		public BankCustomer(int customerId, String customerName, String password, int accountBalance) {
			super();
			this.customerId = customerId;
			this.customerName = customerName;
			this.password = password;
			this.accountBalance = accountBalance;
		}

		public int getCustomerId() {
			return customerId;
		}

		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}

		public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}

		public int getAccountBalance() {
			return accountBalance;
		}

		public void setAccountBalance(int accountBalance) {
			this.accountBalance = accountBalance;
		}

		@Override
		public String toString() {
			return "BankCustomer [customerId=" + customerId + ", customerName=" + customerName + ", password="
					+ password + ", accountBalance=" + accountBalance + "]";
		}
		
		
}
