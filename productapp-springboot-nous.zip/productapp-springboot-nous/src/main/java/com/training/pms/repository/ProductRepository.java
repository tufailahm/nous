package com.training.pms.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.training.pms.model.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{
		public List<Product> findByProductName(String productName);
		public List<Product> findByPriceGreaterThan(int price);
		public List<Product> findByPriceBetween(int min,int max);
		public Product findByQuantityOnHandGreaterThanAndProductId(int quantityOnHand,int productId);

}
