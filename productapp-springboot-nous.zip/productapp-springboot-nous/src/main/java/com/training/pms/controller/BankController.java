package com.training.pms.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.pms.model.BankCustomer;

@RestController
@RequestMapping("bankcustomer")	//localhost:9090/bankcustomer
public class BankController {

	
	//login
	@GetMapping("/validate/{username}/{password}")	//localhost:9090/bankcustomer/validate/ahmed/816721abc
	public String validateCustomer(
			@PathVariable("username") String username,
			@PathVariable("password") String password)
	{
				//code to check whether this user is valid or not 
				return "valid user";
	}
	
	//register
	@PostMapping()	//localhost:9090/bankcustomer	- POST
	public String validateCustomer(@RequestBody BankCustomer bankCustomer)		//JSON
	{
				//code to check save this user in DB
				System.out.println(bankCustomer);
				return "congrats , "+bankCustomer.getCustomerName()+ " you are registered successfully";
	}
	
}
