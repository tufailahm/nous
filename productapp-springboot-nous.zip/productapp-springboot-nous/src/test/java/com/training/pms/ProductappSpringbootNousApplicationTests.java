package com.training.pms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductappSpringbootNousApplicationTests {

	@Test
	void contextLoads() {
	}

}
