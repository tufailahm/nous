package com;

public class Client {

	public static void main(String[] args) {
			ProductApp productApp = new ProductApp();
			productApp.startProductApp();
			
			
		
	}

}
