package com.maybank.pms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.maybank.pms.model.Product;
import com.maybank.pms.utilities.DBConnection;

public class ProductDAOImpl implements ProductDAO {

	Connection con = DBConnection.getDBConnection();

	@Override
	public boolean addProduct(Product product) {
		int rows = 0;
		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement("insert into product values ( ?,?,?,?)");
			statement.setInt(1, product.getProductId());
			statement.setString(2, product.getProductName());
			statement.setInt(3, product.getQuantityOnHand());
			statement.setInt(4, product.getPrice());

			rows = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (rows == 0)
			return false;
		else
			return true;
	}

	@Override
	public boolean updateProduct(Product product) {
		int rows = 0;
		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(
					"update product set productName = ?, quantityOnHand = ?, price = ? where productId = ?");
			statement.setInt(4, product.getProductId());
			statement.setString(1, product.getProductName());
			statement.setInt(2, product.getQuantityOnHand());
			statement.setInt(3, product.getPrice());

			rows = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (rows == 0)
			return false;
		else
			return true;
	}

	@Override
	public boolean deleteProduct(int productId) {
		int rows = 0;
		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement("delete from product where productId = ?");
			statement.setInt(1, productId);
			rows = statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (rows == 0)
			return false;
		else
			return true;
	}

	@Override
	public List<Product> viewProducts() {

			List<Product> products = new ArrayList<Product>();
			
			Statement stat;
		try {
			stat = con.createStatement();
			ResultSet res = stat.executeQuery("select * from product");


			while (res.next()) {
					Product tempProduct = new Product();
					tempProduct.setProductId(res.getInt(1));
					tempProduct.setProductName(res.getString(2));
					tempProduct.setQuantityOnHand(res.getInt(3));
					tempProduct.setPrice(res.getInt(4));
					products.add(tempProduct);
					
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return products;
	}

	@Override
	public boolean isProductExists(int productId) {
		ResultSet rows = null;
		PreparedStatement statement = null;
		boolean productExists=false;
		try {
			statement = con.prepareStatement("select * from product where productId = ?");
			statement.setInt(1, productId);
			rows = statement.executeQuery();
			if(rows.next()) {
				productExists = true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return productExists;
	}

	@Override
	public Product searchProductById(int productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> searchProductByName(String productName) {
		// TODO Auto-generated method stub
		return null;
	}
}
