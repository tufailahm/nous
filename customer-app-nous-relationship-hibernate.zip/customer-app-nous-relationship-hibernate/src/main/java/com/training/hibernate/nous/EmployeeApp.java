package com.training.hibernate.nous;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.training.hibernate.nous.model.Address;
import com.training.hibernate.nous.model.Employee;

public class EmployeeApp 
{
    public static void main( String[] args )
    {
    	Employee employee1 = new Employee(1, "Tufail", 178000);
    	Employee employee2 = new Employee(2, "Neha", 278000);
    	
    	Address address1 = new Address(100, "Bangalore", "Karnataka", "560029");
    	Address address2 = new Address(101, "Hyderabad", "Telangana", "460029");
    	Address address3 = new Address(102, "Mysore", "Karnataka", "360029");

    	//this will create the connection by reading information from hibernate.cfg.xml
    	Configuration configuration = new Configuration().configure();	
    	SessionFactory sessionFactory = configuration.buildSessionFactory();
    	Session session = sessionFactory.openSession();
    	
    	Transaction transaction = session.beginTransaction();
    	
    	Set tufailAddress = new HashSet();
    	Set nehaAddress = new HashSet();
    	
    	tufailAddress.add(address1);		
    	tufailAddress.add(address3);
    	
    	nehaAddress.add(address1);
    	nehaAddress.add(address2);
    	nehaAddress.add(address3);
    	
    	employee1.setAddress(tufailAddress);
    	employee2.setAddress(nehaAddress);
    	
    	//correction , we have to save addresses as well
    	session.save(address1);
    	session.save(address2);
    	session.save(address3);
    	session.save(employee1);	 //saving employee as well as address details for tufail
    	session.save(employee2); 	//saving employee as well as address details for neha
    	transaction.commit();
    	
    	System.out.println("Employees and there addresses saved successfully");
    	
    	session.close();
    	sessionFactory.close();
    }
}
